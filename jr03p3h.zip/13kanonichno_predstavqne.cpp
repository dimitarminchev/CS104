#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Въведете N (10..10000): ";
    cin >> N;

    if (N < 10 || N > 10000) {
        cout << "Числото е извън допустимия интервал!" << endl;
        return 1;
    }

    cout << "Прости делители на " << N << ": ";

    for (int i = 2; i <= N; i++) {
        if (N % i == 0) {
            cout << i << " ";
            while (N % i == 0) {
                N /= i;
            }
        }
    }

    cout << endl;
    return 0;
}