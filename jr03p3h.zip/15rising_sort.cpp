#include <iostream>
using namespace std;

bool isIncreasing(int number) {
    int hundreds = number / 100;           // стотици
    int tens = (number / 10) % 10;         // десетки
    int units = number % 10;               // единици

    return (hundreds < tens) && (tens < units);
}

int main() {
    int a, b;
    cout << "Въведете две естествени числа от интервала [100..999]: ";
    cin >> a >> b;

    if (a > b) {
        int temp = a;
        a = b;
        b = temp;
    }

    int count = 0;

    for (int i = a; i <= b; i++) {
        if (isIncreasing(i)) {
            count++;
            cout << i << " ";
        }
    }

    cout << endl << "Брой числа с нарастваща наредба: " << count << endl;

    return 0;
}