#include <iostream>
using namespace std;

int main() {
    double V, D1, D2, D3;
    cin >> V >> D1 >> D2 >> D3;

    double D = D1 + D2 + D3;
    double t = V / D;

    cout << t << endl;

    if (D1 < 0 || D2 < 0 || D3 < 0) {
        cout << "Една от тръбите изпразва басейна." << endl;
    }

    return 0;
}