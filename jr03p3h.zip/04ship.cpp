#include <iostream>
using namespace std;

int main() {
    double S, Vk, Vt;
    cin >> S >> Vk >> Vt;

    double V = Vk + Vt;
    double t = S / V;

    cout << "Време = " << t << endl;

    if (Vt < 0) {
        cout << "Корабът е срещу течението" << endl;
    } else if (Vt > 0) {
        cout << "Корабът е по течението" << endl;
    } else {
        cout << "Няма течение" << endl;
    }

    return 0;
}