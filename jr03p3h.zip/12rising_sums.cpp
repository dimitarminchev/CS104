#include <iostream>
using namespace std;

int main() {
    int n, m, k;
    cout << "Въведете n, m и k: ";
    cin >> n >> m >> k;

    int suma = 0;

    for (int i = 1; i <= k; i++) {
        int current_sum = n + i * m;
        cout << current_sum << " ";
        suma += current_sum;
    }

    cout << endl << "S = " << suma << endl;

    return 0;
}