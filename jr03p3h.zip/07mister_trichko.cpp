#include <iostream>
using namespace std;

int main() {
    int N;
    cin >> N;

    int b, h;
    int length = 0;
    int maxHeight = 0;

    for (int i = 0; i < N; i++) {
        cin >> b >> h;
        length += b;

        if (h > maxHeight) {
            maxHeight = h;
        }
    }

    cout << "Дължина = " << length << endl;
    cout << "Ширина = " << maxHeight << endl;

    return 0;
}