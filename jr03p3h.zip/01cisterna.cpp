#include <iostream>
using namespace std;

int main() {
    int V;
    cin >> V;

    int both = V / 5;
    int remainder = V % 5;

    cout << both << " пъти двете кофи." << endl;

    if (remainder == 0) {

    } else if (remainder == 1) {
        cout << "Остава 1 литър, можем да използваме кофата от 2 литра." << endl;
    } else if (remainder == 2) {
        cout << "Остава 2 литра, можем да използваме кофата от 2 литра." << endl;
    } else if (remainder == 3) {
        cout << "Остава 3 литра, можем да използваме кофата от 3 литра." << endl;
    } else if (remainder == 4) {
        cout << "Остават 4 литра, можем да използваме и двете кофи още веднъж." << endl;
    }

    return 0;
}