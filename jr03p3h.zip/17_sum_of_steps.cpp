#include <iostream>
#include <vector>
using namespace std;

int main() {
    long long N;
    int S;
    cin >> N >> S;

    vector<long long> powers;

    long long p = 1;
    while (p <= N) {
        powers.push_back(p);
        p *= S;
    }

    vector<long long> result;

    for (int i = powers.size() - 1; i >= 0; i--) {
        while (N >= powers[i]) {
            result.push_back(powers[i]);
            N -= powers[i];
        }
    }

    for (size_t i = 0; i < result.size(); i++) {
        cout << result[i];
        if (i != result.size() - 1)
            cout << ", ";
    }
    cout << endl;

    return 0;
}