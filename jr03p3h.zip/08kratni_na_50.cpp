#include <iostream>
using namespace std;

int main() {
    int N, M;
    cin >> N >> M;

    int start = max(N, M);
    int end = min(N, M);

    for (int i = start; i >= end; i--) {
        if (i % 50 == 0) {
            cout << i << " ";
        }
    }

    return 0;
}