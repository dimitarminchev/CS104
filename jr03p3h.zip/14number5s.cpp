#include <iostream>
using namespace std;

int main() {
    int a, b;
    cout << "Въведете две естествени числа от интервала [100..1000]: ";
    cin >> a >> b;

    // Уверяваме се, че a <= b
    if (a > b) {
        int temp = a;
        a = b;
        b = temp;
    }

    int count = 0;

    for (int i = a; i <= b; i++) {
        int number = i;
        while (number > 0) {
            if (number % 10 == 5) {
                count++;
            }
            number /= 10;
        }
    }

    cout << "Брой петици: " << count << endl;

    return 0;
}