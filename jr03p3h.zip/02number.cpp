#include <iostream>
using namespace std;

int main() {
    int n;
    cin >> n;

    int a = n / 100;
    int b = (n / 10) % 10;
    int c = n % 10;

    int product = a * b * c;

    cout << "Произведение = " << product << endl;

    if (product != 0 && n % product == 0) {
        cout << "Числото е кратно на цифрите си." << endl;
    } else {
        cout << "Числото не е кратно на цифрите си." << endl;
    }

    return 0;
}