#include <iostream>
using namespace std;

int main() {
    int sum;
    cin >> sum;

    for (int n = 100; n <= 999; n++) {
        int a = n / 100;
        int b = (n / 10) % 10;
        int c = n % 10;

        if (a + b + c == sum) {
            cout << n << " ";
        }
    }

    return 0;
}