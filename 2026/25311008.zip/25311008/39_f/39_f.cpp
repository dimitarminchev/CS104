// 39_f.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream> // cout,cin
#include <cmath> // pow
using namespace std;
int main()
{
    const int N = 1000; // Max amount of elements
    int F[N + 1]; // 
    float sum = 0;

    int n, x;
    cout << "Enter x: ";
    cin >> x;
    cout << "Enter n: ";
    cin >> n;


    // Finding massive's elements
    for (int k = 1; k <= n; k++)
    {
        F[k] = pow(x, k);
        sum += F[k];
    }
    cout << "Sum=" << sum << endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
