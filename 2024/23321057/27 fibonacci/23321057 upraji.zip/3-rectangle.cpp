//Периметър на правоъгълник
#include<iostream>
using namespace std;
int main() 
{
    int a, b, p;
        cout << "a=" ;
        cin >> a;
        cout << "b=";
        cin >>b;
        p = a * b;
        cout << p << endl;
    return 0;
}
