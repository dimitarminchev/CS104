#include<iostream>
using namespace std;
int main()
{
    int a, b;

    cout << "a=";
    cin >> a;
    cout << "b=";
    cin >> b;

    int p = 2 * (a+b);
   

    cout << "p=" << p << endl;
    
    return 0;
}