﻿// 01_Hello.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
#define print(x) std::cout<<x<<std::endl;

int main()
{
    print("Hello World");
    return 0;
}

