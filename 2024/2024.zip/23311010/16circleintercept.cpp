#include<iostream>
#include<cmath>
using namespace std;

int main()
{
    float x1,y2,x2,y2,r1,r2;
    cout <<"x1 y1 r1"<<endl;
    cin >> x1 >> y1 >> r1;
    cout <<"x2 y2 r2" <<endl;
    cin >> x2 >> y2 >> r2;

    float x3 = 
    float y3 = 
    float y4 =
    float y4 =

    
    cout << "First point: " << x3 << y3 << endl;
    cout << "Second point: " << x4 << y4 << endl;

}