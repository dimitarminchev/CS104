#include<iostream>
using namespace std;
int main () 
{
    int n,sum=0;
    cin>> n;
    for (int i = 1; i <= 100; i++)
    {
        sum = sum + i;
    }
    count << sum << endl;
    return 0;   
}