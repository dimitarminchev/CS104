// Периметър и лице на правоъгълник по дадени две страни
#include<iostream>
using namespace std; 
int main() 
{
    int a, b, p;
    cout << "a=";
    cin >> a;
    cout << "b=";
    cin >> b;
    p = a * b;
    cout << p << endl;
    return 0;
}
