#include<iostream>
using namespace std;
int main () 
{
    int n,pro=1;
    cin >> n;
    for (int i = 1; i i <= n; i++)
    {
       pro=pro*i;
    }
    count << pro << endl;
    return 0;   
}