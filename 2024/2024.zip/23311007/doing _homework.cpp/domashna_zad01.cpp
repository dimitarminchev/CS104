#include<iostream>
using namespace std;
int main()
{
    int a,b;

    cout << "a=";
    cin >> a;
    cout << "b=";
    cin >> b;

    int s = a * b;

    cout << "s=" << s << endl;
    
    return 0;
}