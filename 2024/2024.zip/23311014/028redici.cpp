#include <iostream>
using namespace std; 

int main()
{
    float n = 0;
    cin >> n; 
    
    

    for(float i = 1; i <= n;i++)
    {
      cout << 1/i << endl;
    }

    return 0;
}