#include <iostream>
using namespace std;
    int main()
{
    int a = 1;
    do
        {
            cout << a << " ";
            a++;
        }
         while (a <= 100);
    cout << endl;
    return 0;
}