#include <iostream>
using namespace std;
    int main()
{
    int a = 1;
        while (a <= 100);
        {
            cout << a << " ";
            a++;
        }
    cout << endl;
    return 0;
}