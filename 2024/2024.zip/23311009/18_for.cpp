#include <iostream>
using namespace std;
int main()
{
	for (int i = 1; i <= 100; i++)
	{
		cout << i << " ";
	}
	cout << endl;
	return 0;
}
