#include <iostream>
using namespace std;
int main()
{
    int a = 1;
    while(a < 101)
    {
        cout << a << " ";
        a++;
    }   
    return 0;
}
