#include <iostream>
using namespace std;
int main()
{
    int a = 1;
    do
    {
      cout << a << " ";
      a++;
    } 
    while (a < 101);
    
    return 0;

}


