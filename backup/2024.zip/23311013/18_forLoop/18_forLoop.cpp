﻿#include <iostream>
using namespace std;
#define print(x) std::cout<<x<<std::endl;

int main()
{
	for (int i = 1; i <= 100; i++)
	{
		print(i << " ");
	}
	cout << endl;
	return 0;
}