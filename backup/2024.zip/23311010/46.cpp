#include<iostream>
using std::cout;
using std::cin;
using std::endl;
int main()
{
    int n;

    int matrixA[3][3], matrixB[3][3];
    cout << "Enter matrix values: " << endl;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) cin >> matrix[i][j];
        cin >> matrixA[i][j]

    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            cin >> matrixB[i][j];

for (int i = 0; i < 3; i++)
{
    for (int j = 0; j < 3; j++)
    cout << a[i][j] + b[i][j]<< "\t";
    cout << endl;
}
return 0;
}
