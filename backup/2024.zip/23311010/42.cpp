#include<iostream>
using namespace std;
int main()
{
    int n, m;
    cout<<"n, x:";
    cin >> n >> x;

    int a[100];
    for (int i = 0; i < n;i++)
    {
        cin >> a[i];
        if (a[i]==s)
        {
            cout << i << "";
        }
    }
    return 0;
} 