//Redica An = (1 / (1/n))'n
#include <iostream>
#include <cmath>
using namespace std;
int main()
{
    int n;
    cout << "n=";
    cin >> n;

    for (float i = 1; i <= n; i++)
    {
        cout << pow((1.0 + (1.0 / i)), i) << endl;
    }

    return 0;
}
