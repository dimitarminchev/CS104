#include<iostream>
using namespace std;
int main()
{
	// Създаване на три целочислени променливи
	int a, b, c;

	// Въвеждане на стойност за а
	cout << "a=";
	cin >> a;

	// Въвеждане на стойност за b
	cout << "b=";
	cin >> b;

	// Използване на математическа операция събиране
	c = a + b;

	// Отпечатване на резултата
	cout << "sum=" << c << endl;

	return 0;
}