#include <iostream>
using namespace std;
int main()
{
	int a, b;

	cout << "a,b=?" << endl;

	cin >> a >> b;

	int c = a + b;
	cout << "a+b=" << c << endl;

	return 0;
}