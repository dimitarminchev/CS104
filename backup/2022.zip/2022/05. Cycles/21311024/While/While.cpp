#include <iostream>
using namespace std;
int main()
{
    int i = 1;

    while (i <= 100)
    {
        cout << i << " ";
        i++;
    }

    return 0;
}