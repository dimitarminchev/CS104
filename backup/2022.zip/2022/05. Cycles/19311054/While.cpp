#include <iostream>
int main() {
    int i = 1;
    while (i <= 100) {
        std::cout << i << " ";
        i++;
    }
    return 0;
}