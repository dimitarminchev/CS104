#include <iostream>
int main() {
    int i = 1;
    do {
        std::cout << i << " ";
        i++;
    } while (i <= 100);
    return 0;
}