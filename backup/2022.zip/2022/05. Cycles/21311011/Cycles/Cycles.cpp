#include <iostream>
using namespace std;
int main()
{
    int i = 0;

    for (i = 1; i <= 100; i++)
    {
        cout << i << " ";
    }

    return 0;
}
