#include <iostream>
using namespace std;

int main()
{
    int a, b, c;
    a = 12;
    b = 23;
    c = a + b;

    cout << "Sum: " << c;

    return 0;
}