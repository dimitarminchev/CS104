﻿#include <iostream>
using namespace std;
int main()
{
    // Извеждаме на екрана "Здравей свят!"
    cout << "Hello World!" << endl;
    return 0;
}