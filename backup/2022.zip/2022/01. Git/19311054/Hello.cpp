#include <iostream>
int main() {
    // Извеждаме на екрана "Здравей свят!"
    std::cout << "Hello World!" << std::endl;
    return 0;
}