#include <iostream>
using namespace std;

int main()
{
    int a = 2, b = 3;
    int c = a + b;
    cout << "a+b=" << c << endl;
    return 0;
}